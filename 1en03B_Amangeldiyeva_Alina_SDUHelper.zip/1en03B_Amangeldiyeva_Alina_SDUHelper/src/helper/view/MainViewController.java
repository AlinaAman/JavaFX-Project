
package helper.view;

import helper.Main;
import java.io.IOException;
import javafx.fxml.FXML;


public class MainViewController  {

   //private Main main;
    
    @FXML
    private void goHome() throws IOException{
        Main.showMainItems();
        
    }
    
    @FXML
    private void addBtn() throws IOException{
        Main.showAddStage();
    }
     
   @FXML
   private void goAboutUs() throws IOException{
       Main.showAboutUsScene();
   }
   
  
}

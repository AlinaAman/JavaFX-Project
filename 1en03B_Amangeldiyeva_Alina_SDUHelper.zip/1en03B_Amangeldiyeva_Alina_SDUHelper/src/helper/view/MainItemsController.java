
package helper.view;

import helper.Main;
import java.io.IOException;
import javafx.fxml.FXML;


public class MainItemsController {

 
   @FXML
   private void goEngineering() throws IOException{
       Main.showEngScene(); 
   }
   
   @FXML
   private void goSocial() throws IOException{
       Main.showSocialScene();
   }
  
}

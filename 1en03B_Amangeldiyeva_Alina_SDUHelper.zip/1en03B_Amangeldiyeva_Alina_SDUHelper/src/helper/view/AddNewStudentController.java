
package helper.view;

import helper.Main;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Calendar;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;


public class AddNewStudentController {
    ObservableList<String> statusList = FXCollections.observableArrayList("Teacher", "Student", "University Department");
    
    
    ObservableList<String> mainDepartmentList = FXCollections.observableArrayList("Engineering", "Public Policy");
    
    ObservableList<String> engineeringList=FXCollections.observableArrayList("Robotics","R&D");
     
    ObservableList<String> socialList=FXCollections.observableArrayList("Economics", "Management");
    
    int mySet; 
    
    //Contact Information;
    @FXML
    private TextField nameField;
    @FXML
    private TextField addressField;
    @FXML
    private TextField cityField;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField emailField;
    
    //Personal Informations;
    @FXML
    private DatePicker dateofBirth;
    @FXML
    private TextField ageField;
    @FXML
    private ChoiceBox statusBox;
    @FXML
    private RadioButton maleBtn;
    @FXML
    private RadioButton femaleBtn;
    
    //Student Informations
    @FXML
    private TextField subjectField;
    @FXML
    private ComboBox mainDepartmentBox;
    @FXML
    private ComboBox departmentBox;
    @FXML
    private CheckBox yesBox;
    @FXML
    private CheckBox noBox;
    @FXML
    private ToggleGroup gender;
    
    @FXML
    private void initialize(){ 
        statusBox.setItems(statusList); //for checkbox - statusBox
        statusBox.setValue("Student");
        
        mainDepartmentBox.setValue("Engineering");
        mainDepartmentBox.setItems(mainDepartmentList);
        
        departmentBox.setValue("Robotics");
        departmentBox.setItems(engineeringList);
    }
    
    
    
    @FXML
    private void showAge(){
        Calendar now=Calendar.getInstance();
        int year=now.get(Calendar.YEAR);
        int birthYear = (dateofBirth.getValue().getYear());
        int age=year - birthYear;
        ageField.setText(Integer.toString(age)+ " Years");
    }
    
    @FXML
    private void mainDepartmentChoice(){
        if (mainDepartmentBox.getValue().equals("Engineering")){
            departmentBox.setValue("Robotics");
            departmentBox.setItems(engineeringList);
        }  
            else {
    departmentBox.setValue("Public Policy");
    departmentBox.setItems(socialList);
    }
}
    
    @FXML
    private void handleYesBox(){
        if(yesBox.isSelected()){
            noBox.setSelected(false);
        }
    }
  
    @FXML
    private void handleNoBox(){
        if(noBox.isSelected()){
            yesBox.setSelected(false);
        }
    }
    
    
    @FXML
    private void goCancel() throws IOException{
        Main.addDialogStage.close();
    }

    @FXML
    private void goOK(ActionEvent event) throws SQLException {
        try{
            Connection con = DriverManager.getConnection("jdbc:sqlite:/home/alina/Pictures/1en03B_Amangeldiyeva_Alina_SDUHelper/alina.db");
            Statement st = con.createStatement();
            if (nameField.getText().isEmpty() || addressField.getText().isEmpty() || cityField.getText().isEmpty() || phoneField.getText().isEmpty()) {
                mySet = 0;
            }
            else if (!nameField.getText().isEmpty() && !addressField.getText().isEmpty() && !cityField.getText().isEmpty() && !phoneField.getText().isEmpty()){
                java.util.Date date = new java.util.Date();
                mySet = st.executeUpdate("insert into test(fullname,address,city, phone, email, datefield, subject) values"
                                                                + "('"+nameField.getText()+"',"
                                                                +"'" + addressField.getText()+"',"
                                                                +"'" + cityField.getText()+"',"
                                                                +"'"+phoneField.getText()+ "'," 
                                                                +"'"+emailField.getText()+ "',"
                                                                +"'"+date.toString()+"'," 
                                                                +"'"+subjectField.getText()+"'"
                                                                +")");
            }
            if(mySet == 1){
                Alert ale = new Alert(Alert.AlertType.INFORMATION);
                ale.setHeaderText("Registration has been done successfully. Thank you!");
                ale.setTitle("Announcement");
                ale.showAndWait();
            }
            else {
                Alert ale = new Alert(Alert.AlertType.ERROR);
                 ale.setHeaderText("Please fill all given gaps");
                ale.setTitle("ERROR! Empty gap/-s");
                ale.showAndWait();
            }
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
  
}

 
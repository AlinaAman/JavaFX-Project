package helper;

import java.sql.Statement;
import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class Main extends Application{
    
    private static Stage primaryStage;
    private static BorderPane mainLayout;
    private static Statement stmt;
    public static Stage addDialogStage;
    
    Media sound = new Media("file:/home/alina/Pictures/1en03B_Amangeldiyeva_Alina_SDUHelper/hello.mp3"); //to put media(mp3)
    MediaPlayer mediaPlayer = new MediaPlayer(sound);
    
    
    
    private static boolean isConnected(){ //check database
        try{
            Class.forName("org.sqlite.JDBC");
            Connection conn = DriverManager.getConnection("jdbc:sqlite:alina.db");
            System.out.println(conn.getSchema());
            stmt = (Statement) conn.createStatement();  
            
            // create table in database
            int mySet;
            mySet = stmt.executeUpdate("CREATE TABLE IF NOT EXISTS test( subject INTEGER PRIMARY KEY AUTOINCREMENT,"+
                    " fullname VARCHAR(255), address VARCHAR(255), city VARCHAR(255), "
                    + "datefield DATE)");
            return true;
        }
        catch(Exception ex){
            ex.printStackTrace();
            return false;
        }
    }
    
       
    @Override
    public void start (Stage primaryStage) throws IOException, InterruptedException, URISyntaxException{
     
        mediaPlayer.play();
     
        this.primaryStage=primaryStage;
        this.primaryStage.setTitle("SDU Helper System");
        showMainView();
        showMainItems();
       
        
        Parent root =FXMLLoader.load(getClass().getResource("view/SplashFXML.fxml"));
        Scene scene=new Scene(root);
        System.out.println(isConnected());
        Stage stage=new Stage();
        stage.initStyle(StageStyle.UNDECORATED);
        stage.setScene(scene);
       
        stage.show();
        TranslateTransition trn = new TranslateTransition(Duration.millis(2500),root); //duration of splash screen
        trn.play();
        trn.setOnFinished(e ->{
            stage.hide();
            try {
                showMainView();
                showMainItems();
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            primaryStage.show();
        });
        
    }

   
    
    private void showMainView() throws IOException{
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(Main.class.getResource("view/MainView.fxml"));
        mainLayout=loader.load();
        Scene scene=new Scene(mainLayout,800,600);
        primaryStage.setScene(scene);
    }
    
    public static void showMainItems() throws IOException{
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(Main.class.getResource("view/MainItems.fxml"));
        BorderPane mainItems=loader.load();
        mainLayout.setCenter(mainItems);
    }
    
    public static void showAboutUsScene() throws IOException{ //new Scene-AboutUs
    FXMLLoader loader=new FXMLLoader();
        loader.setLocation(Main.class.getResource("AboutUs/aboutUs.fxml"));
        StackPane aboutUs = loader.load();
        mainLayout.setCenter(aboutUs); 
    }
    
    public static void showEngScene() throws IOException{
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(Main.class.getResource("engineering/EngineeringDep.fxml"));
        BorderPane engineeringDep = loader.load();
        mainLayout.setCenter(engineeringDep); 
    }
    
    public static void showSocialScene() throws IOException{
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(Main.class.getResource("social/SocialDep.fxml"));
        AnchorPane socialDep = loader.load();
        mainLayout.setCenter(socialDep); 
    }
    
    public static void showAddStage() throws IOException{
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("view/AddNewStudent.fxml"));
        BorderPane addNewStudent=loader.load();
        addDialogStage = new Stage();
        addDialogStage.setTitle("Add new applicant");
        addDialogStage.initModality(Modality.WINDOW_MODAL); //you can not press other scenes
        addDialogStage.initOwner(primaryStage);
        Scene scene=new Scene(addNewStudent);
        addDialogStage.setScene(scene);
        addDialogStage.showAndWait();
    }
    
public static void main(String[]args){
    launch(args);
    
}

}

package helper.engineering;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableView;

/**
 * FXML Controller class
 *
 * @author alina
 */


public class EngineeringDepController implements Initializable {
    
    @FXML
    TableView<String> table = new TableView<>();
    ObservableList<String> data =
            FXCollections.observableArrayList("A");

 
    @Override
    public void initialize(URL url, ResourceBundle rb) { //Initializes the controller class.
        table.setItems(data);
    }    
    
}

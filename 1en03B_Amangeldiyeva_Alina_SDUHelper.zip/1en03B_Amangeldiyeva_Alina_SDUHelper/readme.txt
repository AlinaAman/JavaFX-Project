						
								SDU Helper System

Read Me File

CONTENTS:

1. What is it?

--------

SDU Helper System – is a modern application for students who faced  difficulties in their studies and need someone who can help them. The developer of the SDU HS application is aimed to collaboratively develop the academic system, maintain and make study understandable for others. Everything that is needed to do is to sign up by clicking 'Sign Up' button and fill information gaps about student. Student should fully fill Contact and Personal Information where he writes about subject-(s) which he would like to study. All these data goes through database to table,  that can be seen only to University Department. After that, University Department starts to look for appropriate tutor for students and finally, by using contact information gets in touch with students. As soon as you install application, there will appear splash screen that will dissapear in 5 sec. After that new MainStage with background of SDU is opened and it will demonstrate two main departments(Engineering and Social) clicking on it you could see the general information of each course/list of subjects, then clicking to the button 'AboutUs' you could also find extra information about application.


2. Released date:

--------

17/05/2017, Kazakhstan, Kaskelen, SDU


3.Contacts:

------------

If you want to be informed about new code releases, general news and information about the SDU Helper System subscribe me in vk page or write email on ali099838@gmail.com



4. Minimum system requirements

--------

Linux,Windows:

* Linux(Ubuntu(any versions) XP, Vista, Windows 7, Windows 8
* JDK-8(Java Development Kit, which includes JRE plus the development tools such as compiler and debugger, is need for writing as well as running Java programs) (you can download it here--> https://java.com/download)
* NetBeans 8.0 - platform to work with java 
* Scene Builder 2.0 (available http://www.oracle.com/technetwork/java/javase/downloads/sb2download-2177776.html)
* Sqliteman or Sqlite to work with database
* Media Player(r) 
* 2.33GHz or faster x86-compatible processor 
* 1GB RAM 
* 1024 x 768 screen resolution displaying 32-bit colour 
* Headphones or speakers


5. Running the application

--------

Windows:

To run the application:
* Download application from https://drive.google.com/drive/folders/0By9JKQzjV_CmZ181Q1ItblVjVWM?usp=sharing and extract it to the package
* Compile recently dewnloaded file in cmd like this: cd packageNames --> javac Application.java
* The application should now start.

Linux:

To run the application:
* Download application from https://drive.google.com/drive/folders/0By9JKQzjV_CmZ181Q1ItblVjVWM?usp=sharing and extract it to the package
* Open NetBeans or Eclipse platforms
* Open project from chosen package, press ctrl+f6 to run file
* The application should now start.


6. Technical support

--------

If you experience any problems with the application, please check that you have installed everything from 'Minimum System Requirements' in point 4 above and that you are following the steps outlined in point 5 above. If it still does not work, re-check libraries that are located in dist//lib

If these do not help, do the following: * email me with your query at: ali099838@gmail.com

 	*Be sure to provide the following information:

          - Operating system (e.g. Windows(r) XP)

          - Amount of RAM

          - Processor speed

          - Description of error or problem(screen with ploblems if possible)

  	  - Actions before error occurred

          - Number of times the error has occurred

          - Is the error repeatable? 



7. Libraries that have been used in app:

--------

* JFoenix(JavaFx Material Design Library.)- is an open source Java library, that implements Google Material Design using Java components. 

* SQLite JDBC -  is a library for accessing and creating SQLite database files in Java, developed by Taro L. Saito. Our SQLiteJDBC library requires no configuration since native libraries for major OSs, including Windows, Mac OS X, Linux etc., are assembled into a single JAR (Java Archive) file. The usage is quite simple; download our sqlite-jdbc library, then append the library (JAR file) to your class path or you can skip this step since source code of this application has already contain necessary libraries.



8. The total number of classes/packages/files:

--------

*  The main package - 'helper' consists of four extra packages: 'AboutUs','view','social','engineering'.
*  Main class -1 (also named as Main.java is located in 'helper')
*  'AboutUs' :aboutUs.fxml
*  'view': AddNewStudent.fxml, AddNewStudentController.java, MainItems.fxml, MainItemsController.java, MainView.fxml, MainViewController.java, SplashFXML.fxml, SplashFXMLController.java;
*  'social': SocialDep.fxml;
*  'engineering': EngDep.fxml;


9. Main methods that had been used:

--------

* in src/helper/Main.java there are a list of methods that are responsible for actions and interface of application:

	1. MediaPlayer(sound) - provides application with musicfile as soon as it launched.   
		CodeExample:

		Media sound = new Media("filepath"); 
    		
    	2. isConnected() - boolean method to check wheater app is connected to database or not. In these method has been created the table, 		received data from database. 
		CodeExample:

		Connection conn = DriverManager.getConnection("jdbc:sqlite:alina.db");

    DriverManager: This fully implemented class connects an application to a data source, which is specified by a database URL. 	         When this class first attempts to establish a connection, it automatically loads any JDBC 4.0 drivers found within the class path. Note that your application must manually load any JDBC drivers prior to version 4.0.
    

        3. start() - main method that opens primary stage. To use the interface in my application I must load the FXML file using the FXMLLoader
      		CodeExample:

     		Parent root =FXMLLoader.load(getClass().getResource("view/SplashFXML.fxml"))
 
   
    
	4. private method  showMainView() to open MainView Stage
		CodeExample:

		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/MainView.fxml"));
   
    
	5. showMainItems() to upload the stage with Main Items (home, sign up buttons, etc)
		CodeExample:  
		
		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/MainItems.fxml"));

   
	   	@FXML
	    	private void goHome() throws IOException{
		Main.showMainItems(); }

	    We type this code in MainItemsController to connect button "home"(that is located in MainItems screen )that will return users to 		    the main screen
    
   
    
	6. showAboutUsScene() - new Scene-AboutUs

		CodeExample:

		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(Main.class.getResource("AboutUs/aboutUs.fxml"));
     
    
   	7. showEngScene() 
		
		CodeExample:

        	FXMLLoader loader=new FXMLLoader();
        	loader.setLocation(Main.class.getResource("engineering/EngineeringDep.fxml"));
 
    

	8. showAddStage() - 'sign up' button and new screen with perconal and contact information

		CodeExample:

		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/AddNewStudent.fxml"));
        
		addDialogStage = new Stage();
		addDialogStage.setTitle("Add new applicant");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //you can not press other scenes
	






(c) SDU Helper System 2017 


